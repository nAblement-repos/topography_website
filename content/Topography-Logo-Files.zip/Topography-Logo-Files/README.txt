TOPOGRAPHY CONSULTING LLC - LOGO FILES

SVG/  Vector files. Scale to any size with no loss (use these for print,
      signage and anything sent to a designer or printer).
PNG/  High-resolution images (2000 px wide for the full logo, 1024 px for
      the icon alone). "Transparent" files have no background; "on-White"
      and "on-Navy" files have a solid background.
Favicon/  Website icons: favicon.ico, favicon.svg, 16-512 px PNGs and
      apple-touch-icon.png (180 px) for phones.

Versions
- Color: green-to-navy gradient emblem, navy wordmark (main logo)
- Black: one-color black, for black & white printing, faxes, engraving
- White-Knockout: all-white, for dark backgrounds and photos
- Icon: the round emblem alone, for social profiles and small spaces

Colors: Forest green #215A39 | Navy #094368 | Wordmark navy #0A3F68
